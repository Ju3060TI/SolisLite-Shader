# SolisLite vF-DEBUG (pink water test)
# SolisLite

Ein von Grund auf neu geschriebenes Iris/Sodium-Shader-Pack fuer Minecraft,
das gezielt auf **integrierte Grafikeinheiten** (Intel UHD, Intel Iris Xe,
AMD Radeon iGPUs) zugeschnitten ist. Prioritaet: **Stabilitaet vor
Performance vor Grafikqualitaet.**

Kein Code wurde von bestehenden Shader-Packs uebernommen - alle GLSL-Dateien
sind eigenstaendige, kommentierte Neuentwicklungen.

## Installation

1. Iris + Sodium fuer die passende Minecraft-Version installieren.
2. Den Ordner `SolisLite` (bzw. die `SolisLite.zip`) nach
   `.minecraft/shaderpacks/` legen.
3. Im Spiel: Optionen -> Videoeinstellungen -> Shader-Pakete -> `SolisLite`
   auswaehlen.
4. Ueber den Regler-Bildschirm laesst sich direkt eines der Profile
   **Potato / Low / Balanced / High** waehlen oder jede Einstellung einzeln
   anpassen.

## Funktionsumfang

- **Eigene Beleuchtungs-Engine** (`lib/lighting.glsl`): weiche, eigens
  geformte Lightmap-Kurve statt der linearen Vanilla-Kurve, gerichtetes
  Sonnen-/Mondlicht mit echter Shadow-Map (PCF-gefiltert, distanzverzerrt
  fuer effiziente Aufloesungsnutzung), Wrap-Diffuse-Beleuchtung, damit Gras
  und Laub niemals schwarz erscheinen.
- **Dynamic Lights**: Jedes Item, das als platzierter Block Licht ausstrahlen
  wuerde (Fackel, Laterne, Soul Torch, Soul Lantern, Glowstone, Sea Lantern,
  Redstone-Lampe, etc.), erhellt automatisch die Umgebung des Spielers -
  ueber die Engine-eigene `heldBlockLightValue`-Abfrage, ohne Item-Listen
  von Hand pflegen zu muessen.
- **Eigener 2D-Himmel** (`lib/sky.glsl`): analytischer Farbverlauf
  Horizont/Zenit je nach Sonnenwinkel, warmes Sonnenauf-/untergangsglühen,
  atmosphaerischer Dunst - alles ohne Ray-Marching oder
  Atmosphaerenstreuung, also praktisch kostenlos fuer die GPU.
- **2D-Wolken**: die bereits flache Vanilla-Wolkenebene wird beibehalten
  (das ist die guenstigste moegliche "2D"-Loesung) und lediglich hochwertig
  eingefaerbt/animiert.
- **Wasser** mit analytischen Wellen-Normalen, Fresnel-Reflexion (Himmelsfarbe
  statt teurer Screen-Space-Reflections), Screen-Space-Refraktion und
  Tiefenfaerbung.
- **Windanimation** fuer Gras, Blumen, Sapling, Laub und Ranken.
- **Connected Glass**: benachbarte Glasscheiben/-bloecke werden per
  tiefen-gewichteter Nachbearbeitung nahtlos zusammengefuehrt.
- **Verbesserter Nebel** (Distanz + Hoehe), weich zur Himmelsfarbe hin
  ausgeblendet.
- **Farbkorrektur**: Belichtung, Kontrast, Saettigung, sanftes
  Reinhard-Tonemapping.

## Bewusste Design-Entscheidungen fuer iGPU-Performance

- Reines **Forward-Rendering** (keine Deferred-Lighting-Pipeline) - spart
  mehrere vollflaechige Zwischenpuffer und Texturzugriffe.
- Kein Ray Tracing, kein Path Tracing, keine volumetrischen Wolken, kein
  Motion Blur, keine Depth of Field.
- Shadow-Map bewusst moderat aufgeloest (1536px) mit kleinem PCF-Kernel und
  konfigurierbarer Reichweite.
- Alle Zufalls-/Rauscheffekte (Wolken, Sterne-Twinkle, Wellen) nutzen
  guenstige analytische Funktionen statt Textur-Lookups.

## Projektstruktur

```
SolisLite/
  README.md
  LICENSE
  shaders/
    shaders.properties       Optionsmenue, Profile, Render-Ziele
    block.properties         Block-ID-Zuordnung (Wind, Glas)
    lang/                    Uebersetzungen fuer das Optionsmenue
    lib/                     Gemeinsame GLSL-Bibliotheken
      common.glsl            Uniforms, Konstanten, Mathe-Helfer
      lighting.glsl          Beleuchtung, Schatten, Dynamic Lights
      sky.glsl               Himmel-Farbverlaeufe
      clouds.glsl            Wolken-Einfaerbung
      water.glsl             Wellen, Fresnel, Tiefenfaerbung
      wind.glsl              Vegetationsanimation
      fog.glsl                Nebel
      colorgrade.glsl        Finale Farbkorrektur
    gbuffers_*.vsh/.fsh      Geometrie-Programme (Terrain, Wasser, Entities, ...)
    shadow.vsh/.fsh          Schattenkarten-Erzeugung
    composite.vsh/.fsh       Connected Glass, Nebel, Wetterstimmung
    final.vsh/.fsh           Farbkorrektur & Ausgabe
```

## Bekannte Grenzen

- Es gibt keine farbigen Schatten durch buntes Glas (aus Performance-Gruenden
  bewusst weggelassen).
- Die Wasserreflexion nutzt die berechnete Himmelsfarbe statt einer echten
  Spiegelung der Umgebung (Screen-Space-Reflections waeren fuer iGPUs zu teuer).

## Lizenz

MIT-Lizenz, siehe `LICENSE`.

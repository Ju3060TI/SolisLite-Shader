/* SolisLite - gbuffers_weather.vsh
 * Regen- und Schneepartikel. */
#version 120

#include "lib/common.glsl"

varying vec4 vColor;
varying vec2 vTexCoord;
varying vec2 vLightmap;

void main() {
    gl_Position = gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex;
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vLightmap = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vColor    = gl_Color;
}

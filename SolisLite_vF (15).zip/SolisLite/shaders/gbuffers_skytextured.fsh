#version 120
/* DRAWBUFFERS:02 */
#include "lib/common.glsl"
#include "lib/sky.glsl"
uniform sampler2D texture;
varying vec4 vColor;
varying vec2 vTexCoord;
varying float vIsSun;
void main() {
    if (vIsSun > 0.5) discard;
    vec4 tex = texture2D(texture, vTexCoord);
    if (tex.a < 0.05) discard;
    float sunH = clamp((mat3(gbufferModelViewInverse) * normalize(sunPosition)).y, -1.0, 1.0);
    if (sunH > 0.0 && luma(tex.rgb * vColor.rgb) > 0.5) discard;
    vec3 col = tex.rgb * vColor.rgb * vec3(0.85, 0.88, 0.98);
    vec4 o = vec4(col, tex.a * vColor.a);
    gl_FragData[0] = o;
    gl_FragData[1] = o;
}

/* SolisLite - gbuffers_textured.fsh */
#version 120
/* DRAWBUFFERS:02 */ // 0=colortex0 (Bildschirm), 2=colortex2 (Kopie fuer Wasser-Refraktion)

uniform sampler2D texture;

varying vec2 vTexCoord;
varying vec4 vColor;

void main() {
    vec4 tex = texture2D(texture, vTexCoord);
    if (tex.a < 0.05) discard;
    vec4 outColor0 = tex * vColor;
    gl_FragData[0] = outColor0;
    gl_FragData[1] = outColor0;
}
